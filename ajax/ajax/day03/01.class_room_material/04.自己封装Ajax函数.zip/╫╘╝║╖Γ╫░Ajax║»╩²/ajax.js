/**
 * 这里编写封装的代码
 * 请求的url：
 *    1. get测试地址：http://www.liulongbin.top:3006/api/getbooks
 *    2. post测试地址：http://www.liulongbin.top:3006/api/addbook
 *
 * 参考步骤：
 *    1. 封装 resolveData 函数，对传递过来的请求参数对象转成字符串，例如： name=zs&age=18
 *       - 遍历对象，拼接对象的 key 和 value
 *    2. 定义 itheima 函数
 *       - 初始化 xhr
 *       - 调用 resolveData 函数，传递进去 options.data 请求参数对象
 *       - 监听 onreadystatechange 函数，通过 xhr.readyState === 4 && xhr.status === 200判断是否成功，成功之后利用 JSON.parse() 把服务器返回的数据转成JS对象
 *    3. 判断请求方式
 *       - 根据传递过来的参数 options 里面的 method 属性来判断是 GET 请求 还是 POST 请求
 *       - 如果是 GET 请求，直接把参数拼接在URL地址后面
 *       - 如果是 POST 请求，先设置 Content-Type 为 application/x-www-form-urlencoded，再调用 xhr.send() 方法，把请求参数携带进去
 */

/**
 * 把请求参数对象转成查询字符串格式
 * @param {*} data 请求参数
 */
const resolveData = data => {};

/**
 * 自定义的Ajax函数
 * @param {*} options 参数对象
 */
const itheima = options => {};
