window.onload = function () {
  let xhr = new XMLHttpRequest();
  xhr.open('GET', 'http://www.liulongbin.top:3005/api/getnewslist')
  xhr.send()

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      console.log(xhr.responseText)
      let data = JSON.parse(xhr.responseText).message
      // 4. 调用 template 函数
      let htmlStr = template('tpl-user', {
        data: data
      })
      console.log(htmlStr)
      // 5. 渲染HTML结构
      $('.publish').html(htmlStr)
    }
  }

}