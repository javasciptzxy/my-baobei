$(function () {
  
    // 获取新闻列表的函数
    function getNewsList() {
      $.get('http://www.liulongbin.top:3006/api/news', function (res) {
        if (res.status !== 200) {
          return alert('获取新闻列表数据失败！')
        }
        // TODO：
        // 参考步骤：
        // 1. 在请求成功的回调里面，调用 template() 方法，传入相应数据
        // 2. 通过template()方法返回值生成HTML字符串，渲染在页面
        // 5. 在调用template()方法之前对返回的tags进行截取处理
        // 6. 回到模板页面，通过each对tags进行遍历
      })
    }
  
    getNewsList()
  
  })
  