function jsonp(options) {
    // 1. 获得随机小数后转换成字符串并去掉小数点，得到类似：003220654259774114的随机字符串
    var randomStr = Math.random().toString().replace('.', '');
    // 2. 拼接回调函数名
    var globalFunctionName = 'Function' + randomStr;
    // 3. 构造url地址：类似: https://api.asilu.com/geo/?callback=Function003220654259774114
    var url = `${options.url}?callback=${globalFunctionName}`;
    // 5. 创建script的DOM对象
    var scriptDom = document.createElement('script');
    // 6. 声明全局回调函数
    window[globalFunctionName] = function callback(res) {
        // 9 调用用户在参数中声明的回调函数
        options.success(res);
        // 10 移除script的DOM对象
        document.body.removeChild(scriptDom);
        // 11 移除全局回调函数
        window[globalFunctionName] = null;
    }
    // 7. 设置script的src属性
    scriptDom.setAttribute('src', url);
    // 8. 把scriptDOM对象添加到body尾部
    document.body.appendChild(scriptDom);
}